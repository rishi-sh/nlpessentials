# NLP Essentials

Essential and Fundametal aspects of Natural Language Processing with hands-on examples and case-studies
